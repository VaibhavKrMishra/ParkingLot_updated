package com.example.Vaibhav;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaibhavApplication {

	public static void main(String[] args) {
		SpringApplication.run(VaibhavApplication.class, args);
	}

}
