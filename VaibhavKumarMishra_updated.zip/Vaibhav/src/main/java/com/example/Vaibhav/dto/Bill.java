package com.example.Vaibhav.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import org.springframework.stereotype.Component;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Entity
@Table(name="Bill")
public class Bill {

	@javax.persistence.Id
	@GeneratedValue(strategy =  GenerationType.AUTO)
	private Long id;
	
	private String startTime;
	private String endTime;
	private String generatedAt;
	private int amount;
	
}
