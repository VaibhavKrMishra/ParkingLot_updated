package com.example.Vaibhav.service;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Vaibhav.dto.Bill;
import com.example.Vaibhav.dto.Duration;

@Service
public interface BillService {

	public Bill generateBill(@RequestBody Duration duration) throws ParseException;
	public Optional<Bill> showBill(Long id);
	public List<Bill> showAllBills();
}
