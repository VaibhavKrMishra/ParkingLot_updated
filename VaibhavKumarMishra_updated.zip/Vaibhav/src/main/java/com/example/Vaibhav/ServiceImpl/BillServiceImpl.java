package com.example.Vaibhav.ServiceImpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Vaibhav.dto.Bill;
import com.example.Vaibhav.dto.Duration;
import com.example.Vaibhav.repository.BillRepository;
import com.example.Vaibhav.service.BillService;

@Component
public class BillServiceImpl implements BillService {

	@Autowired
	private BillRepository billRepository;

	@Override
	public Bill generateBill(@RequestBody Duration duration) throws ParseException {
		// TODO Auto-generated method stub
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date startTime = format.parse(duration.getEntryTime());
		Date endTime = format.parse(duration.getExitTime());
		if(startTime.compareTo(endTime)>0) {
			Bill toBePaid = new Bill();
			toBePaid.setAmount(0);
			toBePaid.setStartTime(duration.getEntryTime());
			toBePaid.setEndTime(duration.getExitTime());
			toBePaid.setGeneratedAt("Invalid data");
			return toBePaid;

		}
		long difference = (endTime.getTime() - startTime.getTime())/(1000*3600) ;
		Calendar c = Calendar.getInstance();
		c.setTime(startTime);
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		System.out.println(difference);
		if (dayOfWeek > 5) {
			if (difference <= 2) {

				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(5);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);

				billRepository.save(toBePaid);
				return toBePaid;

			} else if (difference <= 5) {

				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(8);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);
				billRepository.save(toBePaid);
				return toBePaid;

			} else if (difference <= 10) {

				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(12);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);
				billRepository.save(toBePaid);
				return toBePaid;

			} else if (difference <= 15) {

				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(18);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);
				billRepository.save(toBePaid);
				return toBePaid;

			} else {

				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(25);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);
				billRepository.save(toBePaid);
				return toBePaid;

			}
		} else {
			if (difference <= 2) {
				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(7);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);
				billRepository.save(toBePaid);
				return toBePaid;
			} else if (difference <= 5) {
				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(10);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);
				billRepository.save(toBePaid);
				return toBePaid;

			} else if (difference <= 10) {

				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(15);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);
				billRepository.save(toBePaid);
				return toBePaid;
			} else if (difference <= 15) {
				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(22);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);
				billRepository.save(toBePaid);
				return toBePaid;

			} else {
				String generatedAt = format.format(System.currentTimeMillis());
				Bill toBePaid = new Bill();
				toBePaid.setAmount(30);
				toBePaid.setStartTime(duration.getEntryTime());
				toBePaid.setEndTime(duration.getExitTime());
				toBePaid.setGeneratedAt(generatedAt);
				billRepository.save(toBePaid);
				return toBePaid;
			}
		}
	}

	@Override
	public Optional<Bill> showBill(Long id) {
		// TODO Auto-generated method stub
		return billRepository.findById(id);
	}

	@Override
	public List<Bill> showAllBills() {
		// TODO Auto-generated method stub
		return (List<Bill>) billRepository.findAll();
	}

}
