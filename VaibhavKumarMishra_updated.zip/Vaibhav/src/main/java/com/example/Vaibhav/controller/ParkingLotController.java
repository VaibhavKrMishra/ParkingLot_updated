package com.example.Vaibhav.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.Vaibhav.ServiceImpl.BillServiceImpl;
import com.example.Vaibhav.dto.Bill;
import com.example.Vaibhav.dto.Duration;
import com.example.Vaibhav.service.BillService;

import java.net.http.HttpResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/ParkingLot")
public class ParkingLotController {

	@Autowired
	private BillService billService;
	@PostMapping("/GetBill")
	public Bill getBill(@RequestBody Duration duration) throws ParseException {
			return billService.generateBill(duration);
	}
	
	@GetMapping("/GetAllBills")
	public List<Bill> getAllBills(){
		return billService.showAllBills();
	}
	@PostMapping("BillById")
	public Optional<Bill> getBillById(@RequestBody Long id){
		return billService.showBill(id);
	}
	
}
