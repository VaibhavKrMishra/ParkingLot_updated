package com.example.Vaibhav;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaibhavApplicationTests {

	@Test
	void contextLoads() {
	}

}
